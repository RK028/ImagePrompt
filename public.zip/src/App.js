import React, { useState } from 'react';
import { Container } from 'react-bootstrap';
import InputForm from './components/Forms';
import ImageView from './components/View';

const App = () => {
    const [imageUrl, setImageUrl] = useState('');

    const handleGenerate = async (prompt) => {
        // You can perform your image generation logic here
        // For example, fetch from an API or generate locally
        // Replace with actual logic to fetch or generate image
        const generatedImageUrl = `https://image.smiligence.info`;
        setImageUrl(generatedImageUrl);
    };

    return (
        <Container className="my-4">
            <InputForm onGenerate={handleGenerate} />
            {imageUrl && <ImageView imageUrl={imageUrl} />}
        </Container>
    );
};

export default App;
