import React from 'react';
import './View.css'; // Import CSS file

const ImageView = ({ imageUrl }) => {
    return (
        <div className="image-view-container">
            <h2>Generated Image</h2>
            <img src={imageUrl} alt="Generated" />
        </div>
    );
};

export default ImageView;
