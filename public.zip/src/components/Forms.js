import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import './Forms.css'; // Import CSS file

const InputForm = ({ onGenerate }) => {
    const [prompt, setPrompt] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        onGenerate(prompt);
        setPrompt('');
    };

    return (
        <div className="input-form-container">
            <h2>Generate Image</h2>
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formPrompt">
                    <Form.Label>Enter Your Prompt:</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Describe what you want to see..."
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        required
                    />
                </Form.Group>
                <Button variant="primary" type="submit">
                    Generate Image
                </Button>
            </Form>
        </div>
    );
};

export default InputForm;
